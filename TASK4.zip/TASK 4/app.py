
import streamlit as st
import os
os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"  # Suppress symlink warning
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import FAISS
from langchain.llms import HuggingFacePipeline
from langchain.chains import ConversationalRetrievalChain
from langchain.memory import ConversationBufferMemory
from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline

# Load vector store
embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
vector_store = FAISS.load_local("faiss_index", embeddings, allow_dangerous_deserialization=True)

# Load LLM
model_name = "distilgpt2"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(model_name)
text_generation_pipeline = pipeline(
    "text-generation",
    model=model,
    tokenizer=tokenizer,
    max_length=200,
    truncation=True,
    pad_token_id=tokenizer.eos_token_id
)
llm = HuggingFacePipeline(pipeline=text_generation_pipeline)

# Set up conversational memory
if "memory" not in st.session_state:
    st.session_state.memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)

# Create RAG chain
retriever = vector_store.as_retriever(search_kwargs={"k": 2})
qa_chain = ConversationalRetrievalChain.from_llm(
    llm=llm,
    retriever=retriever,
    memory=st.session_state.memory
)

# Streamlit app
st.title("Context-Aware Chatbot")
user_input = st.text_input("Ask a question:", "")

if user_input:
    result = qa_chain({"question": user_input})
    st.write("**Answer**:")
    st.write(result["answer"])
    
    # Display chat history
    st.write("**Chat History**:")
    for msg in st.session_state.memory.chat_memory.messages:
        role = "User" if msg.__class__.__name__ == "HumanMessage" else "Bot"
        st.write(f"{role}: {msg.content}")